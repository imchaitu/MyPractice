from setuptools import setup

setup(
    name='mypackage',
    version='0.0.1',
    install_requires=[
        'requests'
    ],
)