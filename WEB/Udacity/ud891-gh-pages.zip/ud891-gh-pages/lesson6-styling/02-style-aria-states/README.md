See if you can do a better job styling this button using ARIA states. One huge
benefit to styling with ARIA is that it provides visual feedback that you've
applied the state correctly, which can act as a safeguard when you're testing
and debugging your code.
