Visual presentation doesn't match DOM order
There are floated elements and absolutely positioned elements, completely screwing up the
tab flow.
Currently failing audit tool :\
