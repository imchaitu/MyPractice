See if you can figure out what needs to be added to the `modal.js` file to trap
the keyboard.

There's quite a bit of code involved in created a keyboard trap so don't worry
if it seems overwhelming. Take your time and refer back to [this video](https://www.udacity.com/course/viewer#!/c-ud891/l-7962031279/m-7962141423)
if you get stuck.
